const n="/icons/icon-design-page.png";export{n as _};
